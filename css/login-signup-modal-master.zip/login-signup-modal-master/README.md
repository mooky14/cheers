Login/Signup modal window
=========

Front-end coded version of a modal window to login/signup into your website. Once opened, the user can easily switch from one form to the other, or select the reset password option.

[Article on CodyHouse](http://codyhouse.co/gem/loginsignup-modal-window/)

[Demo](http://codyhouse.co/demo/login-signup-modal-window/)
 
[Terms](http://codyhouse.co/terms/)
